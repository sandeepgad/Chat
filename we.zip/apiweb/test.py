from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))

if __name__ == '__main__':
    with app.app_context():
        try:
            db.drop_all() # Bindings lekundaa drop_all() call cheyandi
            print("Main tables dropped (minimal app - no bindings)")
            db.create_all() # Bindings lekundaa create_all() call cheyandi
            print("Main tables created (minimal app - no bindings)")
        except TypeError as e:
            print(f"TypeError in minimal app (no bindings): {e}")
        except Exception as e:
            print(f"Other error in minimal app (no bindings): {e}")