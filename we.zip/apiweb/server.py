import flask_sqlalchemy
print(f"Flask-SQLAlchemy Version: {flask_sqlalchemy.__version__}")
import sqlalchemy
print(f"SQLAlchemy Version: {sqlalchemy.__version__}")

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail, Message
import secrets
import os
from werkzeug.security import generate_password_hash, check_password_hash
import re
import requests
import validators
from functools import wraps
from bleach import clean
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///database.db' # Main database - ONLY ONE DATABASE NOW
# app.config['SQLALCHEMY_BINDS'] = { # REMOVED BINDINGS CONFIGURATION
#     'temp':    os.environ.get('TEMP_DATABASE_URL') or 'sqlite:///temp_database.db' # Temporary database
# }
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'unqchat@gmail.com'
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = 'unqchat@gmail.com'
app.config['SESSION_COOKIE_DOMAIN'] = None
app.config['SESSION_COOKIE_PATH'] = '/'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = False

db = SQLAlchemy(app)
mail = Mail(app)

TEMP_DATA_EXPIRY_MINUTES = 5 # Temporary data expiry time - 5 minutes - NOT USED ANYMORE

class User(db.Model): # Main User model - in 'default' bind (database.db) - NO BIND ANYMORE
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True, nullable=False)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    is_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(255))
    role = db.Column(db.String(20), default='user')
    registration_time = db.Column(db.DateTime)

# class TempUser(db.Model): # Temporary User model - in 'temp' bind (temp_database.db) - REMOVED TEMPUSER MODEL
#     __bind_key__ = 'temp' # Bind to 'temp' database
#     id = db.Column(db.Integer, primary_key=True)
#     name = db.Column(db.String(100))
#     email = db.Column(db.String(100), unique=True, nullable=False)
#     username = db.Column(db.String(80), unique=True, nullable=False)
#     password_hash = db.Column(db.String(255), nullable=False) # Store hashed password
#     verification_token = db.Column(db.String(255))
#     registration_time = db.Column(db.DateTime, default=datetime.utcnow) # Registration timestamp


class Settings(db.Model): # Settings model - in 'default' bind (database.db) - NO BIND ANYMORE
    id = db.Column(db.Integer, primary_key=True)
    api_endpoint = db.Column(db.String(255), default="facebook/blenderbot-400M-distill")

class ChatMessage(db.Model): # ChatMessage model - in 'default' bind (database.db) - NO BIND ANYMORE
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_user_message = db.Column(db.Boolean, nullable=False)
    user = db.relationship('User', backref=db.backref('chat_messages', lazy=True))

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user or user.role != 'admin':
            flash('Admin access required!', 'danger')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        return render_template('dashboard.html', user_name=user.name)
    return redirect(url_for('login'))

@app.route('/profile')
def profile():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        return render_template('profile.html', user=user)
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    email_error = None
    password_error = None
    username_error = None
    name_error = None
    old_values = {}
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        old_values = {'name': name, 'username': username, 'email': email}

        if password != confirm_password:
            password_error = "Passwords do not match"
            return render_template('register.html', password_error=password_error, email_error=email_error, username_error=username_error, old_values=old_values, name_error=name_error)

        if len(password) < 8 or len(password) > 20:
            password_error = "Password must be between 8 and 20 characters"
            return render_template('register.html', password_error=password_error, email_error=email_error, username_error=username_error, old_values=old_values, name_error=name_error)

        if not re.search(r"[a-zA-Z]", password) or not re.search(r"[0-9]", password) or not re.search(r"[^a-zA-Z0-9]", password):
            password_error = "Password must contain letters, numbers, and symbols"
            return render_template('register.html', password_error=password_error, email_error=email_error, username_error=username_error, old_values=old_values, name_error=name_error)

        if not validators.email(email):
            email_error = 'Invalid email format!'
            return render_template('register.html', password_error=password_error, email_error=email_error, username_error=username_error, old_values=old_values, name_error=name_error)

        if not re.match(r'^[a-zA-Z0-9_]+$', username):
            username_error = 'Username can only contain letters, numbers, and underscores!'
            return render_template('register.html', email_error=email_error, password_error=password_error, username_error=username_error, old_values=old_values, name_error=name_error)
        if len(username) < 3 or len(username) > 20:
            username_error = "Username must be between 3 and 20 characters"
            return render_template('register.html', email_error=email_error, password_error=password_error, username_error=username_error, old_values=old_values, name_error=name_error)
        if len(name) < 2 or len(name) > 100:
            name_error = "Name must be between 2 and 100 characters"
            return render_template('register.html', email_error=email_error, password_error=password_error, username_error=username_error, name_error=name_error, old_values=old_values)


        existing_user_email_main = User.query.filter_by(email=email).first()
        if existing_user_email_main:
            email_error = 'Email already registered!'
            return render_template('register.html', email_error=email_error, password_error=password_error, username_error=username_error, old_values=old_values, name_error=name_error)

        existing_user_username_main = User.query.filter_by(username=username).first()
        if existing_user_username_main:
            username_error = 'Username already taken!'
            return render_template('register.html', email_error=email_error, password_error=password_error, username_error=username_error, old_values=old_values, name_error=name_error)

        # existing_temp_user_email = TempUser.query.filter_by(email=email).first() # REMOVED TEMPUSER CHECK
        # if existing_temp_user_email: # REMOVED TEMPUSER CHECK
        #     db.session.delete(existing_temp_user_email) # Remove old temp user if exists - for re-registration # REMOVED TEMPUSER CHECK

        user = User( # Save to User table directly - NO TEMPUSER ANYMORE
            name=name,
            email=email,
            username=username,
            password=generate_password_hash(password), # Hash password before saving
            verification_token=secrets.token_urlsafe(32)
        )
        db.session.add(user)
        db.session.commit()

        send_verification_email(email, user.verification_token) # Send token from User

        return render_template('email_sent.html', email=email)

    return render_template('register.html', email_error=email_error, password_error=password_error, username_error=username_error, old_values=old_values, name_error=name_error)


def send_verification_email(email, token):
    print(f"send_verification_email function called for email: {email}")
    verification_link = url_for('verify_email', token=token, _external=True)
    msg = Message('Please Verify Your UnQChat Account', sender='unqchat@gmail.com', recipients=[email])
    msg.html = f"""
    <html>
    <head></head>
    <body>
        <p>Hello,</p>
        <p>Thank you for registering with UnQChat!</p>
        <p>To activate your account, please verify your email address by clicking the link below:</p>
        <p><a href="{verification_link}">Verify My Email</a></p>
        <p>This verification step helps us ensure the security of our community.</p>
        <p>If you did not register for an account, please disregard this email.</p>
        <p>Best regards,</p>
        <p>The UnQChat Team</p>
    </body>
    </html>
    """
    try:
        mail.send(msg)
        print(f'Verification email sent to {email}')
    except Exception as e:
        print(f'Error sending email: {e}')

@app.route('/verify/<token>')
def verify_email(token):
    print("verify_email function called with token:", token)
    user = User.query.filter_by(verification_token=token).first() # Search User table directly - NO TEMPUSER ANYMORE
    if not user:
        flash('Invalid or expired verification link.', 'warning') # Updated message
        return redirect(url_for('login'))

    user.is_verified = True # Verify user directly in User table - NO TEMPUSER ANYMORE
    user.verification_token = None # Clear verification token
    # db.session.add(user) # NO NEED TO ADD AGAIN, ALREADY IN SESSION
    db.session.commit()
    flash('Email verified successfully! You can now login.', 'success')
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    login_error = None
    if request.method == 'POST':
        email_or_username = request.form['email_or_username']
        password = request.form['password']

        user = User.query.filter_by(username=email_or_username).first() # Search User table directly - NO TEMPUSER ANYMORE

        if not user: # Check only User table now - NO TEMPUSER ANYMORE
            user = User.query.filter_by(email=email_or_username).first()

        if user: # Check User table directly - NO TEMPUSER ANYMORE
            if check_password_hash(user.password, password):
                session['user_id'] = user.id
                admin_username = os.environ.get('ADMIN_USERNAME')
                if user.username == admin_username:
                    session['admin_logged_in'] = True
                    return redirect(url_for('admin'))
                return redirect(url_for('home'))
            else:
                login_error = 'Invalid credentials!'
        else:
            login_error = 'Invalid credentials!'

    return render_template('login.html', login_error=login_error)


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('admin_logged_in', None)
    session.pop('chat_history', None)
    return redirect(url_for('index'))

@app.route('/check_email', methods=['POST'])
def check_email():
    email = request.form['email']
    existing_user_main = User.query.filter_by(email=email).first() # Check only User table - NO TEMPUSER ANYMORE
    # existing_temp_user = TempUser.query.filter_by(email=email).first() # REMOVED TEMPUSER CHECK
    if existing_user_main: # Check only User table - NO TEMPUSER ANYMORE
        return jsonify({'exists': True})
    else:
        return jsonify({'exists': False})

@app.route('/suggest_username', methods=['POST'])
def suggest_username():
    data = request.get_json()
    name = data.get('name', '')
    if name:
        username_suggestion = name.split()[0].lower() + secrets.token_hex(2)
        return jsonify({'suggested_username': username_suggestion})

@app.route('/chat')
def chat():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        chat_history = session.get('chat_history', [])
        return render_template('chat_screen.html', user_name=user.name, chat_history=chat_history)
    return redirect(url_for('login'))

@app.route('/get_ai_response', methods=['POST'])
def get_ai_response():
    user_message = request.get_json()['message']
    if not user_message or len(user_message) > 500:
        return jsonify({'response': "Error: Message too long or empty."})

    sanitized_message = clean(user_message)
    print(f"User Message (Sanitized): {sanitized_message}")

    api_key = os.environ.get('HUGGINGFACE_API_KEY')
    if not api_key:
        return jsonify({'response': "Error: Hugging Face API key not configured."})

    settings = Settings.query.first()
    api_endpoint_model_name = settings.api_endpoint

    full_api_endpoint_url = f"https://api-inference.huggingface.co/models/{api_endpoint_model_name}"

    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {"inputs": sanitized_message}

    try:
        response = requests.post(full_api_endpoint_url, headers=headers, json=payload)
        print("Debugging: API Response Status Code:", response.status_code)
        response.raise_for_status()
        ai_response_data = response.json()
        ai_response_text = ai_response_data[0]['generated_text']

        session_chat_history = session.get('chat_history', [])
        session_chat_history.append({'type': 'user', 'text': sanitized_message, 'timestamp': datetime.now().strftime('%H:%M')})
        session_chat_history.append({'type': 'ai', 'text': ai_response_text, 'timestamp': datetime.now().strftime('%H:%M')})
        session['chat_history'] = session_chat_history

        return jsonify({'response': ai_response_text})
    except requests.exceptions.RequestException as e:
        error_message = f"Error: Could not connect to Hugging Face API. {e}"
        print(f"Debugging: API Request Error: {error_message}")
        return jsonify({'response': error_message})

@app.route('/admin')
@admin_required
def admin():
    user = User.query.get(session['user_id'])
    users = User.query.all()
    settings = Settings.query.first()
    return render_template('admin.html', users=users, settings=settings, user=user)

@app.route('/admin/settings', methods=['GET', 'POST'])
@admin_required
def admin_settings():
    settings = Settings.query.first()
    if request.method == 'POST':
        new_api_endpoint = request.form['api_endpoint']

        if not validators.url(new_api_endpoint):
            flash('Invalid API Endpoint URL format!', 'danger')
            return render_template('admin_settings.html', settings=settings)

        settings.api_endpoint = new_api_endpoint
        db.session.commit()
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('admin_settings'))
    return render_template('admin_settings.html', settings=settings)

@app.route('/admin/delete_user/<int:user_id>')
@admin_required
def delete_user(user_id):
    admin_username = os.environ.get('ADMIN_USERNAME')
    user_to_delete = User.query.get(user_id)

    if not user_to_delete:
        flash('Invalid user ID!', 'danger')
        return redirect(url_for('admin'))

    if user_to_delete.username == admin_username:
        flash('Cannot delete admin user!', 'danger')
        return redirect(url_for('admin'))

    db.session.delete(user_to_delete)
    db.session.commit()
    flash('User deleted successfully!', 'success')
    return redirect(url_for('admin'))

# **Background task to clear TempUser table (Conceptual - Not fully implemented in this code)** - REMOVED CLEAR_TEMP_USERS FUNCTION

# **Updated WAN Connection Code**
if __name__ == '__main__':
    with app.app_context():
        # db.drop_all(bind='temp') # Drop temp database tables - REMOVED TEMP DATABASE
        # print("Temporary tables dropped.") # REMOVED TEMP DATABASE
        # db.create_all(bind='temp') # Create temp database tables - REMOVED TEMP DATABASE
        # print("Temporary tables created.") # REMOVED TEMP DATABASE

        db.drop_all() # Drop main database tables - ONLY MAIN DATABASE NOW
        print("Main tables dropped.")
        db.create_all() # Create main database tables - ONLY MAIN DATABASE NOW
        print("Main tables created.")


        admin_username_env = os.environ.get('ADMIN_USERNAME')
        admin_password_env = os.environ.get('ADMIN_PASSWORD')
        secret_key_env = os.environ.get('SECRET_KEY')
        mail_password_env = os.environ.get('MAIL_PASSWORD')

        if not admin_username_env or not admin_password_env or not secret_key_env or not mail_password_env:
            print("Error: ADMIN_USERNAME, ADMIN_PASSWORD, SECRET_KEY, and MAIL_PASSWORD environment variables are not set!")
            print("Please set these variables before running the server.")
        else:
            app.config['SECRET_KEY'] = secret_key_env
            app.config['MAIL_PASSWORD'] = mail_password_env
            admin_user = User.query.filter_by(username=admin_username_env).first()
            if not admin_user:
                admin_user = User(name='Admin User', email='admin@example.com', username=admin_username_env, password=generate_password_hash(admin_password_env), is_verified=True, role='admin')
                db.session.add(admin_user)
                db.session.commit()
                print("Admin user created using environment variables.")
            else:
                print("Admin user already exists.")

        if not Settings.query.first():
            default_settings = Settings()
            db.session.add(default_settings)
            db.session.commit()
            print("Settings table initialized with default values.")

        # **Conceptual call to clear temp users - In real app, use background scheduler** - REMOVED CLEAR_TEMP_USERS CALL
        # clear_temp_users() # Clear temp users on startup (for demonstration) - REMOVED CLEAR_TEMP_USERS CALL


        app.run(host='0.0.0.0', port=5000, debug=True)