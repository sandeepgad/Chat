function suggestUsername() {
    let nameInput = document.getElementById("name");
    let usernameInput = document.getElementById("username");

    if (nameInput.value.length > 2) {
        fetch("/suggest_username", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ name: nameInput.value })
        })
        .then(response => response.json())
        .then(data => {
            usernameInput.value = data.suggested_username;
        });
    }
}

function searchUsers() {
    let input, filter, table, tr, tdName, tdUsername, i, txtValueName, txtValueUsername;
    input = document.getElementById("userSearch");
    filter = input.value.toUpperCase();
    table = document.getElementById("userTable");
    tr = table.getElementsByTagName("tr");

    for (i = 1; i < tr.length; i++) { // Start from 1 to skip header row
        tdName = tr[i].getElementsByClassName("userName")[0]; // Get Name column
        tdUsername = tr[i].getElementsByClassName("userName")[1]; // Get Username column
        if (tdName || tdUsername) {
            txtValueName = tdName.textContent || tdName.innerText;
            txtValueUsername = tdUsername.textContent || tdUsername.innerText;
            if (txtValueName.toUpperCase().indexOf(filter) > -1 || txtValueUsername.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

        const initialMessages = [
            "👋 Hey there! How can I help?",
            "❓ Need help? Just ask!",
            "😊 How’s it going? What do you need?",
            "🤔 Tell me, how can I assist?",
            "🙌 I’m here for you! What’s up?",
            "💭 What’s on your mind?",
            "☀️ How can I make your day easier?",
            "🤝 Need something? I got you!",
            "🔍 Looking for help? Let me know!",
            "🗣️ Hey! What can I do for you?",
            "🤵 How can I assist you today?",
            "📝 Let me know how I can be of service.",
            "✅ Need assistance? I’m here!",
            "❓ What do you need help with?",
            "💼 How may I help you?",
            "🔧 Tell me what you need, and I’ll handle it.",
            "🏅 Looking for guidance? I’m ready.",
            "📌 Your request is my priority! What is it?",
            "📞 I’d love to assist—what’s your query?",
            "🤲 How can I support you today?",
            "✨ Got a question? I’ve got answers! ✨",
            "🚀 Need help? Let’s do this! 🚀",
            "🤖 Your assistant is online! What’s up?",
            "🧐 Curious about something? Ask away!",
            "🔥 Let’s get started! How can I assist?",
            "👋 I’m here! What do you need?",
            "💡 Got an idea? Let’s work on it!",
            "🏆 Need solutions? Let’s go!",
            "🎯 Looking for help? I’m all ears!",
            "⚡ Let’s solve your problem!",
            "🆘 Need assistance?",
            "🏁 How can I help?",
            "💬 Just ask!",
            "🔹 Here to help!",
            "⏳ I’m ready when you are.",
            "❓ What do you need?",
            "🛠️ Looking for support?",
            "🙋‍♂️ How may I assist?",
            "💭 Tell me what’s on your mind.",
            "🔄 Let’s fix this together!",
            "💻 Hello, user! How can I assist?",
            "🤖 Your digital assistant is here!",
            "⚙️ How can I make your task easier?",
            "🟢 Assistance mode: Activated!",
            "🔍 AI ready! What’s your query?",
            "🏗️ Smart assistant at your service!",
            "⚡ Need quick solutions? I got you!",
            "📩 Query received! Awaiting instructions.",
            "🤯 Need automation? Let’s get started!",
            "🤖 AI-powered support is here!",
            "🎮 Yo! What’s the mission?",
            "🚪 Knock knock! Need help?",
            "🎙️ Talk to me, I’m listening!",
            "🏴‍☠️ Ready to assist, Captain!",
            "⌨️ Type away! I’m here for you.",
            "🧞 Your wish is my command!",
            "🔥 Let’s get things done! What’s up?",
            "📦 You ask, I deliver!",
            "🕵️‍♂️ Got a problem? Let’s solve it!",
            "🍽️ Tell me what’s on your plate!",
            "🖥️ System online. Awaiting input...",
            "⚡ Initiating support sequence…",
            "📡 User request detected. Processing...",
            "🔎 Ready to decode your request!",
            "🏗️ Assistance.exe is now running!",
            "🧠 I’m your digital problem solver.",
            "🚀 Let’s optimize your workflow!",
            "🎮 Your command, my action!",
            "🖥️ Booting up support module…",
            "🔬 Debugging your issue… tell me more!",
            "☎️ Thank you for reaching out! How can I help?",
            "📨 We’re here to support you—just ask!",
            "👨‍💼 Need help? Our team is ready!",
            "🏢 Your support request starts here!",
            "🤝 What can I do to assist you?",
            "⚡ Quick support at your fingertips!",
            "🛎️ Your query is important to us!",
            "📖 Got questions? I’ve got answers!",
            "🔍 Need troubleshooting? Let’s do it.",
            "📨 Support is just one message away!",
            "🚀 Let’s make today productive! Need help?",
            "🏋️ Challenges? Let’s tackle them together!",
            "🎯 Need guidance? You got this!",
            "🏆 I’m here to make your journey easier!",
            "💪 Don’t worry, I’ve got your back!",
            "🎖️ Let’s solve this problem like pros!",
            "🔑 You’re one step away from the solution!",
            "🔎 Every problem has a solution—let’s find it!",
            "🤲 You’re in good hands! How can I help?",
            "🚪 Let’s unlock new possibilities together!",
            "❔ Ask me anything!",
            "⚡ Need something done? Just say it!",
            "⏳ No delays—how can I help?",
            "🔍 What do you need right now?",
            "🚀 Let’s get this sorted ASAP!",
            "🎯 I’m ready—shoot your question!",
            "🖱️ Assistance is just a tap away!",
            "🏆 I’ll handle it—what’s your request?",
            "🔄 Here to help, 24/7!",
            "⏳ Ready when you are!"
        ];

        document.addEventListener('DOMContentLoaded', function() {
            const initialMessageTextElement = document.getElementById('initial-message-text');
            const randomIndex = Math.floor(Math.random() * initialMessages.length);
            initialMessageTextElement.textContent = initialMessages[randomIndex];
        });


        let inputAreaExpanded = false;
        let menuOpen = false;
        const inputIconsLeft = document.getElementById('input-icons-left');
        const functionButtonsContainer = document.getElementById('function-buttons');
        const messageInput = document.getElementById('message-input');
            const menuIconContainer = document.getElementById('menu-icon-container');
        const menuDropdown = document.getElementById('menu-dropdown');
        const typingIndicator = document.getElementById('typing-indicator'); // Typing indicator element


        function expandInputArea(event) {
            event.stopPropagation();

            if (!inputAreaExpanded) {
                inputIconsLeft.classList.add('hidden');
                functionButtonsContainer.style.display = 'none';
                messageInput.classList.add('expanded');
                menuIconContainer.classList.add('visible');
                inputAreaExpanded = true;
            }
        }

        function collapseInputArea() {
            if (inputAreaExpanded) {
                inputIconsLeft.classList.remove('hidden');
                functionButtonsContainer.style.display = 'flex';
                messageInput.classList.remove('expanded');
                menuIconContainer.classList.remove('visible');
                inputAreaExpanded = false;
            }
        }


        function handleChatScreenClick(event) {
            if (inputAreaExpanded && !event.target.closest('.chat-input-area')) {
                collapseInputArea();
            }
            if (menuOpen && !event.target.closest('.menu-icon-container')) {
                closeMenu();
            }
        }

        function toggleMenu(event) {
            event.stopPropagation();
            menuDropdown.classList.toggle('open');
            menuOpen = !menuOpen;
        }

        function closeMenu() {
            menuDropdown.classList.remove('open');
            menuOpen = false;
        }


        function sendMessage() {
            const messageInput = document.getElementById('message-input');
            const messageText = messageInput.value;
            if (messageText.trim() !== '') {
                displayMessage('user-message', messageText, getCurrentTimestamp()); // Display user message with timestamp
                adjustInputHeight(messageInput);
                messageInput.value = '';
                messageInput.focus();

                collapseInputArea();
                closeMenu();

                typingIndicator.style.display = 'block'; // Show typing indicator

                fetch('/get_ai_response', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ message: messageText })
                })
                .then(response => response.json())
                .then(data => {
                    typingIndicator.style.display = 'none'; // Hide typing indicator after response
                    displayMessage('ai', data.response, getCurrentTimestamp()); // Display AI response with timestamp
                    // messageInput.focus(); // Refocus on input after message sent - REMOVED FROM HERE
                });
            }
        }

        function displayMessage(messageType, text, timestampText) {
            const chatMessages = document.getElementById('chat-messages');
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', messageType);

            const messageTextDiv = document.createElement('div'); // Container for message text
            messageTextDiv.classList.add('message-text');
            messageTextDiv.textContent = text;

            const timestampDiv = document.createElement('div'); // Container for timestamp
            timestampDiv.classList.add('message-timestamp');
            timestampDiv.textContent = timestampText;

            messageDiv.appendChild(messageTextDiv); // Add text to message div
            messageDiv.appendChild(timestampDiv); // Add timestamp to message div


            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function goToDashboard(fromScreen = '') {
            let url = "{{ url_for('home') }}";
            if (fromScreen === 'chat') {
                url += "?from_chat=true";
            }
            window.location.href = url;
            closeMenu();
        }


        function startNewChat() {
            window.location.href = "{{ url_for('chat') }}";
            closeMenu();
        }

        function adjustInputHeight(input) {
            input.style.height = 'auto';
            input.style.height = (input.scrollHeight) + 'px';
        }

        function getCurrentTimestamp() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            return `${hours}:${minutes}`; // HH:MM format
        }